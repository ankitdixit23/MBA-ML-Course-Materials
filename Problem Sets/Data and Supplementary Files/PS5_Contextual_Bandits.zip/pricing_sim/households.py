# pricing_sim/households.py

import numpy as np
import pandas as pd

def simulate_households_by_state(state_stats, total_n=100000, random_state=42):
    """
    Simulate household-level microdata for each U.S. state based on aggregated state-level statistics.

    This function generates a synthetic population of households, distributing them across states
    proportionally to population size. It simulates demographics, behavioral traits, and prior interactions
    with a firm for use in demand modeling or market simulation.

    Parameters
    ----------
    state_stats : pandas.DataFrame
        A dataframe where each row corresponds to a U.S. state and includes:
            - 'state': state name or abbreviation
            - 'population': total population in the state
            - 'median_income': median household income
            - 'std_income': standard deviation of income
            - 'median_age': median age of household heads
            - 'avg_family_size': average household size
            - 'std_family_size': standard deviation of household size
            - 'race_<group>': number of people in each racial group (e.g., 'race_white', 'race_black', etc.)
            - 'total_pop': total population (used to normalize race shares)

    total_n : int, optional (default=100000)
        Total number of households to simulate across all states.

    random_state : int, optional (default=42)
        Seed for the NumPy random number generator to ensure reproducibility.

    Returns
    -------
    pandas.DataFrame
        A long-format DataFrame where each row represents a simulated household with the following columns:
            - 'state': U.S. state identifier
            - 'income': simulated income (log-normal)
            - 'log_income': log(1 + income), useful for modeling elasticities
            - 'age': age of household head (clipped normal between 18 and 90)
            - 'family_size': rounded number of household members (≥1)
            - 'sex': randomly assigned household head sex ('M' or 'F')
            - 'race': race group label (e.g., 'White', 'Black', etc.)
            - 'product_affinity': baseline preference for a product (Beta distributed)
            - 'price_sensitivity': household-level sensitivity to price (normal distribution)
            - 'ad_sensitivity': responsiveness to ads (normal distribution)
            - 'prev_interactions': number of past interactions with the firm
              (80% have 0, 12% have 1, rest have 2+ drawn from Poisson + 2)

    Notes
    -----
    - The final DataFrame contains approximately `total_n` households, proportionally distributed by state.
    """
    np.random.seed(random_state)
    households = []

    # Compute total US population in the file
    total_pop = state_stats["population"].sum()

    # Determine number of households per state (rounded)
    state_stats["n_households"] = (
        (state_stats["population"] / total_pop) * total_n
    ).round().astype(int)

    # Adjust total in case rounding creates mismatch
    diff = total_n - state_stats["n_households"].sum()
    if diff != 0:
        # Correct the difference by adjusting the largest state
        max_idx = state_stats["n_households"].idxmax()
        state_stats.loc[max_idx, "n_households"] += diff

    # Populate households for each state based on state-level stats
    for _, row in state_stats.iterrows():
        state = row["state"]
        n = row["n_households"]
        
        # 1. Income (log-normal around median and std)
        sigma = row["std_income"] / row["median_income"]
        income = np.random.lognormal(mean=np.log(row["median_income"]), sigma=sigma, size=n)
        log_income = np.log1p(income)

        # 2. Age (normal clipped to [18, 90]) using default std
        age = np.clip(
            np.random.normal(loc=row["median_age"], scale=12, size=n),
            18, 90
        )
        
        #### Deprecated: Using poisson instead
        ## 3. Family size (normal -> round -> at least 1)
        #family_size = np.clip(
        #    np.round(np.random.normal(loc=row["avg_family_size"], scale=row["std_family_size"], size=n)),
        #    1, None
        #).astype(int)

        # 3. Family size (Poisson around average family size)
        family_size = np.clip(
            np.random.poisson(lam=row["avg_family_size"], size=n),
            1, None
        ).astype(int)

        # 4. Sex of HH head
        sex = np.random.choice(["M", "F"], size=n, p=[0.7, 0.3])

        # 5. Race using shares
        races = ["Native", "Asian", "Black", "Hispanic", "Pacific", "Other", "White"]
        race_probs = np.array([row[f"race_{r.lower()}"]/row["population"] for r in races])
        race_probs = race_probs / race_probs.sum()
        race = np.random.choice(races, size=n, p=race_probs)

        # 6. Latent behavior
        product_affinity = np.random.beta(2, 2, size=n)
        price_sensitivity = np.random.normal(-0.5, 0.1, size=n)
        ad_sensitivity = np.random.normal(0.5, 0.2, size=n)

        # 7. Previous interaction with the firm
        interaction_probs = np.random.rand(n)
        prev_interactions = np.zeros(n, dtype=int)
        prev_interactions[(interaction_probs > 0.8) & (interaction_probs <= 0.92)] = 1
        prev_interactions[interaction_probs > 0.92] = np.random.poisson(lam=2, size=(interaction_probs > 0.92).sum()) + 2
        
        # Combine into DataFrame
        state_df = pd.DataFrame({
            "state": state,
            "income": income,
            "log_income": log_income,
            "age": age,
            "family_size": family_size,
            "sex": sex,
            "race": race,
            "product_affinity": product_affinity,
            "price_sensitivity": price_sensitivity,
            "ad_sensitivity": ad_sensitivity,
            "prev_interactions": prev_interactions
        })
        households.append(state_df)

    df = pd.concat(households, ignore_index=True)

    # Add unique household id
    df.insert(0, "hh_id", np.arange(len(df), dtype=np.int64))

    return df