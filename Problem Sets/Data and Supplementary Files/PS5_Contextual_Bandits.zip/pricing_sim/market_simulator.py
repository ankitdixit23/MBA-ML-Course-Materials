# pricing_sim/market_simulator.py
import numpy as np
import pandas as pd
from .utility_functions import compute_individual_utility
from sklearn.linear_model import LinearRegression

class DisjointLinearUCB:
    """
    Disjoint Linear UCB (LinUCB): one linear model per action.

    Each action a has parameters:
      A[a] (d x d), b[a] (d,)
    theta[a] = A[a]^{-1} b[a]
    score = x^T theta[a] + alpha * sqrt(x^T A[a]^{-1} x)
    """

    def __init__(self, actions, d, alpha=1.0, lambda_reg=1.0, rng=None):
        self.actions = np.array(list(actions), dtype=float) # The available arms, prices
        self.d = int(d) # The number of context features, including the intercept
        self.alpha = float(alpha)   # exploration strength, bigger means more exploration
        self.lambda_reg = float(lambda_reg)
        self.rng = rng if rng is not None else np.random.default_rng()

        # For every action a, create a matrix A[a]
        # It starts with identity matrix, because data is not available in the beggining
        self.A = {a: self.lambda_reg * np.eye(self.d) for a in self.actions}
        # Vector b, will accumulate reward-weighted contexts over time
        self.b = {a: np.zeros(self.d) for a in self.actions}

    def select_action(self, x):
        """
        Choose the best action for this context.

        Takes customer features and returns the price to offer
        """
        x = np.asarray(x, dtype=float).reshape(-1)
        assert x.shape[0] == self.d

        # Initialize best action and score. I will loop over the actions and
        # keep the one with the highest score
        best_a = None
        best_score = -np.inf

        for a in self.actions:
            A_inv = np.linalg.inv(self.A[a])
            # Theta is the current estimate of the linear relationship
            # predicted_reward = x @ theta 
            theta = A_inv @ self.b[a]
            mean = float(x @ theta)
            # Compute the uncertainty bonus. If the bandit has not tried this action
            # much, the uncertainty is big, bonus is big, so more exploration
            bonus = float(self.alpha * np.sqrt(x @ A_inv @ x))
            # Final UCB score = predicted reward + exploration bonus
            score = mean + bonus

            # Keep the best scoring action
            if score > best_score:
                best_score = score
                best_a = a

        return float(best_a)

    def update(self, x, a, r):
        """
        Learn from what happened. After you choose an action, and observe reward
        this updates the model for that action
        """
        x = np.asarray(x, dtype=float).reshape(-1)
        a = float(a)
        r = float(r)

        # Update the matrix of info A. Each time you use action a, you add
        # information abouit that context. Over time, A[a] grows and uncertainty
        # shrinks.
        self.A[a] += np.outer(x, x)
        self.b[a] += r * x

class RetailMarketSim:
    """
    Dynamic retail market simulation with:
    - New and returning arrivals
    - Depreciation-based return probabilities
    - macroeconomy (binary Markov) affecting costs + demand
    - Optional household/month panel hisrtory for prediction tasks
    """

    def __init__(
        self,
        households_df,
        base_cost=15.0,
        base_price=35.0,
        sigma_cost=2.0,
        arrival_rate=0.05,
        T=50,
        random_state=42,
        id_col="hh_id",

        # Arrival dynamics
        new_customer_share=0.30,        # fraction of arrivals drawn from never-seen pool (when available)
        return_base_prob=0.25,          # baseline return probability for seen consumers
        return_depreciation=0.25,       # per-period decay in return probability since last seen (0<d<=1)

        # Macroeconomy process
        macro_p_good_to_bad=0.10,       # P(bad | good)
        macro_p_bad_to_good=0.35,       # P(good | bad)
        macro_cost_multiplier_bad=1.08, # costs higher when macro is bad (supply shocks)
        macro_utility_shift_bad=-0.40,  # households less likely to buy when macro is bad

        # Inflation
        monthly_inflation_mu=0.002,     # ~0.2% monthly
        monthly_inflation_sigma=0.001,  # noise
        apply_inflation_to_cost=True,
        apply_inflation_to_price_bounds=False,

        # Bandit (contextual pricing)
        bandit_actions=None,
        bandit_alpha=1.0,
        bandit_lambda=1.0,
        bandit_reward="profit",   # "profit" or "revenue"
        context_cols=None,        # which household columns to use as context

        # A/B test (randomized pricing)
        ab_prices=(25.0, 35.0),   # (low_price, high_price)
        ab_prob_high=0.5,          # P(assign high price)

        # Output granularity
        store_household_panel=True
    ):
        self.rng = np.random.default_rng(random_state)

        self.households = households_df.copy()
        if id_col not in self.households.columns:
            self.households[id_col] = np.arange(len(self.households))
        self.id_col = id_col

        # Keep a stable index for fast lookup
        self.households.set_index(self.id_col, inplace=True, drop=False)

        # Demand curve data (empirical)
        self.demand_data = {
            15.0: 0.93402, 16.0: 0.90379, 17.0: 0.8662, 18.0: 0.82405, 19.0: 0.77531,
            20.0: 0.72464, 21.0: 0.67017, 22.0: 0.6153, 23.0: 0.56157, 24.0: 0.50824,
            25.0: 0.45617, 26.0: 0.40711, 27.0: 0.36244, 28.0: 0.32275, 29.0: 0.28409,
            30.0: 0.24937, 31.0: 0.21791, 32.0: 0.1903, 33.0: 0.16543, 34.0: 0.14411,
            35.0: 0.12544, 36.0: 0.10873, 37.0: 0.09396, 38.0: 0.08119, 39.0: 0.06965,
            40.0: 0.05959, 41.0: 0.05134, 42.0: 0.04358, 43.0: 0.03675, 44.0: 0.03078,
            45.0: 0.02571, 46.0: 0.02139, 47.0: 0.0169, 48.0: 0.01366, 49.0: 0.01107,
            50.0: 0.00848
        }

        # Base firm settings
        self.base_cost = base_cost
        self.base_price = base_price
        self.sigma_cost = sigma_cost
        self.arrival_rate = arrival_rate
        self.T = T

        # Arrival behavior parameters
        self.new_customer_share = new_customer_share
        self.return_base_prob = return_base_prob
        self.return_depreciation = return_depreciation

        # Macroeconomy parameters
        self.macro_p_good_to_bad = macro_p_good_to_bad
        self.macro_p_bad_to_good = macro_p_bad_to_good
        self.macro_cost_multiplier_bad = macro_cost_multiplier_bad
        self.macro_utility_shift_bad = macro_utility_shift_bad

        # Inflation parameters
        self.monthly_inflation_mu = monthly_inflation_mu
        self.monthly_inflation_sigma = monthly_inflation_sigma
        self.apply_inflation_to_cost = apply_inflation_to_cost
        self.apply_inflation_to_price_bounds = apply_inflation_to_price_bounds

        # Dynamic state
        self.macro_state = 1  # 1=good, 0=bad (start good by default)
        self.price_index = 1.0

        # Tracking seen/returning consumers
        self.seen_ids = set()
        self.last_seen = {}  # hh_id -> last period seen
        self.customer_ledger = {}  # hh_id -> stats dict

        # ---- Contextual bandit config ----
        self.bandit_reward = bandit_reward

        # Default context columns (simple + stable)
        if context_cols is None:
            context_cols = ["log_income", "age", "family_size", "product_affinity", "ad_sensitivity", "prev_interactions"]
        self.context_cols = context_cols

        # Default action space: use your demand_data prices if none passed
        if bandit_actions is None:
            bandit_actions = sorted(list(self.demand_data.keys()))
        self.bandit_actions = bandit_actions

        # Context dimension = len(context_cols) + intercept
        self._context_dim = len(self.context_cols) + 1

        self.bandit = DisjointLinearUCB(
            actions=self.bandit_actions,
            d=self._context_dim,
            alpha=bandit_alpha,
            lambda_reg=bandit_lambda,
            rng=self.rng
        )

        # A/B testing
        self.ab_prices = tuple(ab_prices)
        self.ab_prob_high = float(ab_prob_high)

        # Outputs
        self.results = []
        self.store_household_panel = store_household_panel
        self.hh_panel = []  # household-month rows

    # ------------------
    # Macroeconomy state
    # ------------------

    def update_macro_state(self):
        """Binary Markov chain for macroeconomy."""
        if self.macro_state == 1:
            # good -> bad
            if self.rng.random() < self.macro_p_good_to_bad:
                self.macro_state = 0
        else:
            # bad -> good
            if self.rng.random() < self.macro_p_bad_to_good:
                self.macro_state = 1

    def update_inflation(self):
        """Update price index with monthly inflation shock"""
        infl = self.rng.normal(self.monthly_inflation_mu, self.monthly_inflation_sigma)
        self.price_index *= (1.0 + infl)
        return infl
    
    # ---------------------
    # Firm cost and pricing
    # ---------------------
    def draw_cost_real(self):
        """
        Draw real marginal cost around base_cost with noise, clipped
        """
        cost = self.rng.normal(loc=self.base_cost, scale=self.sigma_cost)
        return float(np.clip(cost, 5, 50))
    
    def draw_cost_nominal(self):
        """
        Convert real cost to nominal using macro + inflation
        """
        c = self.draw_cost_real()

        # macro shock on costs when situation is bad
        if self.macro_state == 0:
            c *= self.macro_cost_multiplier_bad

        # inflation
        if self.apply_inflation_to_cost:
            c *= self.price_index

        return float(c)
    
    def estimate_demand_params(self):
        """
        Estimate linear demand parameters (a, b) from dict{price: purchase_rate}
        """
        prices = np.array(list(self.demand_data.keys())).reshape(-1, 1)
        q = np.array(list(self.demand_data.values()))
        model = LinearRegression().fit(prices, q)
        a = float(model.intercept_)
        b = float(-model.coef_[0]) # Negative so Q(p)=a-bp
        return a, b

    def choose_price(self, cost, policy="empirical"):
        """
        Determine price based on policy. 
        """
        pmin, pmax = 10.0, 50.0
        if self.apply_inflation_to_price_bounds:
            pmin *= self.price_index
            pmax *= self.price_index

        if policy == "empirical":
            a, b = self.estimate_demand_params()
            price_opt = (a + b * cost) / (2 * b) # monopoly price for linear model
            return float(np.clip(price_opt, pmin, pmax))
        elif policy == "fixed":
            return float(self.base_price * (self.price_index if self.apply_inflation_to_price_bounds else 1.0))
        elif policy == "cost_plus":
            return float(np.clip(cost * 1.3, pmin, pmax))
        elif policy == "random":
            return float(self.rng.uniform(pmin, pmax))
        else:
            raise ValueError(f"Unknown policy: {policy}")
        
    # ---------------------------
    # Arrivals: new and returning 
    # ---------------------------

    def _return_prob(self, last_seen_t, current_t):
        """
        Depreciation-based probability of returning.
        If depreciation < 1: probability decays the longer they have not appeared
        """
        dt = current_t - last_seen_t
        return self.return_base_prob * (self.return_depreciation ** dt)
    
    def sample_consumers(self, t):
        """
        Draw arrivals from:
            - new pool of never seen consumers
            - returning pool (seen before) with depreciation-based show-up probability
        """
        n_arrivals = int(self.arrival_rate * len(self.households))
        if n_arrivals <= 0:
            return self.households.iloc[0:0] # empty df
        
        all_ids = self.households.index.to_numpy()

        seen_ids = np.array(list(self.seen_ids), dtype=all_ids.dtype) if self.seen_ids else np.array([], dtype=all_ids.dtype)
        unseen_mask = ~np.isin(all_ids, seen_ids)
        unseen_ids = all_ids[unseen_mask]

        # How many new arrivals do we want?
        n_new_target = int(round(n_arrivals * self.new_customer_share))
        n_new = min(n_new_target, len(unseen_ids))
        n_return = n_arrivals - n_new

        # Sample new arrivals uniformly from unseen pool
        new_arrivals = np.array([], dtype=all_ids.dtype)
        if n_new > 0:
            new_arrivals = self.rng.choice(unseen_ids, size=n_new, replace=False)

        # Sample returning arrivals using per-id return probabilities
        returning_arrivals = np.array([], dtype=all_ids.dtype)
        if n_return > 0 and len(seen_ids) > 0:
            probs = np.array([self._return_prob(self.last_seen[i], t) for i in seen_ids], dtype=float)
            probs = np.clip(probs, 0.0, 1.0)

            # Realize show-ups as Bernoulli, then sample up to n_return if too many
            show = self.rng.random(len(seen_ids)) < probs
            candidates = seen_ids[show]

            if len(candidates) >= n_return:
                returning_arrivals = self.rng.choice(candidates, size=n_return, replace=False)
            else:
                returning_arrivals = candidates  # may be short this period
        
        arrival_ids = np.unique(np.concatenate([new_arrivals, returning_arrivals]))
        arrivals = self.households.loc[arrival_ids].copy()

        # Update "seen" bookkeeping
        for hh_id in arrival_ids:
            self.seen_ids.add(hh_id)
            self.last_seen[hh_id] = t

        return arrivals
    
    def _get_context_vector(self, hh) -> np.ndarray:
        """
        Build context vector x for a household.
        Includes intercept + selected demographic/behavior columns.
        """
        x = [1.0]  # intercept
        for col in self.context_cols:
            val = hh[col] if col in hh else 0.0
            # guard against strings / missing
            try:
                x.append(float(val))
            except Exception:
                x.append(0.0)
        return np.array(x, dtype=float)


    # ---------------
    # Simulation step
    # ---------------
    def simulate_period(
        self,
        t,
        policy="empirical",
        beta_demographics=None,
        beta_behavior=None,
        alpha_demographics=None,
        race_effects=None,
        state_effects=None
    ):
        """
        One period:
          1) update macro + inflation
          2) draw cost, set price
          3) sample arrivals (new + returning)
          4) purchase decisions (macro shifts utility)
          5) aggregate revenue/profit
          6) optional household-month panel rows
        """
        # 1) macro + inflation evolve
        self.update_macro_state()
        infl_t = self.update_inflation()

        # 2) firm cost & price (nominal)
        cost_t = self.draw_cost_nominal()

        if policy in ["contextual_bandit", "ab_test"]:
            price_t = np.nan  # price determined per-customer inside loop
        else:
            price_t = self.choose_price(cost_t, policy)

        # 3) arrivals
        arrivals = self.sample_consumers(t)


        # 4) purchase decisions
        purchases = []
        spend = []

        prices_offered = []  # helpful summary for period-level results
        rewards = []         # bandit reward tracking

        for _, hh in arrivals.iterrows():

            A_i = np.nan
            pi0_i = np.nan

            if policy == "contextual_bandit":
                x = self._get_context_vector(hh)
                price_i = self.bandit.select_action(x)

            elif policy == "ab_test":
                # Randomize per customer (important: within-period)
                low_p, high_p = self.ab_prices
                A_i = int(self.rng.random() < self.ab_prob_high)   # 1 = high price
                price_i = high_p if A_i == 1 else low_p
                pi0_i = self.ab_prob_high if A_i == 1 else (1.0 - self.ab_prob_high)

            else:
                price_i = price_t

            res = compute_individual_utility(
                hh, price_i,
                beta_demographics=beta_demographics,
                beta_behavior=beta_behavior,
                alpha_demographics=alpha_demographics,
                race_effects=race_effects,
                state_effects=state_effects,
                epsilon_std=1.0,
                rng=self.rng,  # only if you added rng support in utility
                macro_state=self.macro_state,
                macro_utility_shift_bad=self.macro_utility_shift_bad
            )

            buy = int(res["purchase"])
            purchases.append(buy)
            prices_offered.append(price_i)

            spend_i = buy * price_i
            spend.append(spend_i)

            # Define reward for the bandit
            if self.bandit_reward == "profit":
                reward_i = buy * (price_i - cost_t)
            elif self.bandit_reward == "revenue":
                reward_i = buy * price_i
            else:
                raise ValueError(f"Unknown bandit_reward: {self.bandit_reward}")

            rewards.append(reward_i)

            # Update bandit only in contextual bandit policy
            if policy == "contextual_bandit":
                self.bandit.update(x, price_i, reward_i)

            # Store panel row
            if self.store_household_panel:
                self.hh_panel.append({
                    "period": t,
                    self.id_col: hh[self.id_col],
                    "macro_state": self.macro_state,
                    "inflation": infl_t,
                    "price_index": self.price_index,

                    "price": float(price_i),
                    "A": A_i,          # (will be 0/1 for ab_test, NaN otherwise)
                    "pi0": pi0_i,      # (0.5/0.5 for ab_test, NaN otherwise)

                    "cost": float(cost_t),
                    "purchase": buy,
                    "spend": float(spend_i),
                    "reward": float(reward_i),
                    "policy": policy,

                    # keep your context columns (and other hh columns) as-is
                    **{col: hh[col] for col in hh.index if col not in [self.id_col]}
                })


            hh_id = hh[self.id_col]

            if hh_id not in self.customer_ledger:
                # store demographics once
                self.customer_ledger[hh_id] = {
                    "visits": 0,
                    "buys": 0,
                    "total_spend": 0.0,
                    "first_seen": t,
                    "last_seen": t,
                    # demographics snapshot (pick what you care about)
                    "age": hh.get("age", np.nan),
                    "log_income": hh.get("log_income", np.nan),
                    "family_size": hh.get("family_size", np.nan),
                    "race": hh.get("race", None),
                    "state": hh.get("state", None),
                }

            # update stats
            rec = self.customer_ledger[hh_id]
            rec["visits"] += 1
            rec["buys"] += buy
            rec["total_spend"] += buy * price_i
            rec["last_seen"] = t

        purchases = np.array(purchases, dtype=int)
        n_purchases = int(purchases.sum())
        total_spend_t = float(np.sum(spend))
        revenue_t = total_spend_t
        profit_t = float(np.sum(np.array(purchases) * (np.array(prices_offered) - cost_t)))
        avg_price_t = float(np.mean(prices_offered)) if len(prices_offered) else np.nan

        self.results.append({
            "period": t,
            "macro_state": self.macro_state,
            "inflation": infl_t,
            "price_index": self.price_index,
            "price": avg_price_t,   # average offered price this period
            "cost": cost_t,
            "arrivals": int(len(arrivals)),
            "purchases": int(np.sum(purchases)),
            "total_spend": total_spend_t,
            "revenue": revenue_t,
            "profit": profit_t,
            "avg_reward": float(np.mean(rewards)) if len(rewards) else np.nan
            })


    def get_customer_summary(self, demo_cols=None) -> pd.DataFrame:
        """
        Aggregate household-month panel into customer-level summary:
        visits, buys, total_spend, first/last period, plus demographics.
        Requires store_household_panel=True (i.e., self.hh_panel populated).
        """
        if not self.store_household_panel:
            raise ValueError("store_household_panel=False, so no household panel exists to summarize.")

        hh_df = pd.DataFrame(self.hh_panel)
        if hh_df.empty:
            return pd.DataFrame(columns=[self.id_col, "visits", "buys", "total_spend", "first_period", "last_period"])

        id_col = self.id_col

        # Default demographics to attach (keep only those that exist)
        if demo_cols is None:
            demo_cols = ["age", "log_income", "family_size", "race", "state"]
        demo_cols = [c for c in demo_cols if c in hh_df.columns]

        cust_summary = (
            hh_df.groupby(id_col)
                .agg(
                    visits=("period", "count"),
                    buys=("purchase", "sum"),
                    total_spend=("spend", "sum"),
                    first_period=("period", "min"),
                    last_period=("period", "max"),
                )
                .reset_index()
        )

        if demo_cols:
            demo = (
                hh_df.sort_values("period")
                    .groupby(id_col, as_index=False)[demo_cols]
                    .first()
            )
            cust_summary = cust_summary.merge(demo, on=id_col, how="left")

        return cust_summary


    def run(self, policy="fixed", return_customer_summary=False, demo_cols=None, **kwargs):
        for t in range(self.T):
            self.simulate_period(t, policy=policy, **kwargs)

        market_df = pd.DataFrame(self.results)

        if self.store_household_panel:
            hh_df = pd.DataFrame(self.hh_panel)

            if return_customer_summary:
                cust_summary = self.get_customer_summary(demo_cols=demo_cols)
                return market_df, hh_df, cust_summary

            return market_df, hh_df

        return market_df

