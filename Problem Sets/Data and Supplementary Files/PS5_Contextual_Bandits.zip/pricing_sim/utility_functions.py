import numpy as np
import pandas as pd

# Define coefficients
beta_demographics = {"log_income": 0.4, "age": -0.01, "family_size": -0.02}
beta_behavior = {"product_affinity": 5.0, "ad_sensitivity": 0.01, "prev_interactions": 0.04}
alpha_demographics = {"log_income": -0.02, "age": 0.005, "family_size": 0.1}

def compute_static_utility(df_households: pd.DataFrame, price: float = 35,
                           noise_share: float = 0.2, epsilon_std: float = 1.0,
                           random_state: int = 42) -> pd.DataFrame:
    """
    Compute household-level utility and purchase decision for a given price.

    This function encodes race and state effects, applies demographic and behavioral
    coefficients, adds random shocks, and outputs a DataFrame with computed utilities
    and purchase decisions.

    Parameters
    ----------
    df_households : pd.DataFrame
        DataFrame of simulated households from `simulate_households_by_state`.

    price : float, default=35
        Price of the product offered by the firm.

    noise_share : float, default=0.2
        Fraction of households that experience random shocks in utility.

    epsilon_std : float, default=1.0
        Standard deviation of the random noise term.

    random_state : int, default=42
        Random seed for reproducibility.

    Returns
    -------
    pd.DataFrame
        The same DataFrame with added columns:
            - 'utility' : latent utility for each household
            - 'purchase' : binary purchase indicator (1 if utility > 0)
            - one-hot encoded race/state columns
    """

    np.random.seed(random_state)
    df = df_households.copy()

    # 1. One-hot encode race and state
    df = pd.get_dummies(df, columns=["race", "state"], drop_first=True)

    # 2. Identify one-hot columns
    race_cols = [col for col in df.columns if col.startswith("race_")]
    state_cols = [col for col in df.columns if col.startswith("state_")]

    # 3. Simulate fixed effects (random coefficients per race/state)
    race_effects = {col: np.random.normal(loc=0.0, scale=0.2) for col in race_cols}
    state_effects = {col: np.random.normal(loc=0.0, scale=0.3) for col in state_cols}

    race_contrib = df[race_cols].dot(pd.Series(race_effects))
    state_contrib = df[state_cols].dot(pd.Series(state_effects))

    # 4. Coefficients
    beta_0 = 0

    beta_demographics = {
        "log_income": 0.4,
        "age": -0.01,
        "family_size": -0.02
    }

    beta_behavior = {
        "product_affinity": 5.0,
        "price_sensitivity": 0.0,
        "ad_sensitivity": 0.01,
        "prev_interactions": 0.04
    }

    alpha_0 = 0
    alpha_demographics = {
        "log_income": -0.02,
        "age": 0.005,
        "family_size": 0.1
    }

    # 5. Random shocks
    n = len(df)
    epsilon = np.zeros(n)
    affected = np.random.choice(n, size=int(noise_share * n), replace=False)
    epsilon[affected] = np.random.normal(0, epsilon_std, len(affected))

    # 6. Utility components
    U_demo = sum(beta_demographics[var] * df[var] for var in beta_demographics)
    U_behavior = sum(beta_behavior[var] * df[var] for var in beta_behavior)
    alpha_i = alpha_0 + sum(alpha_demographics[var] * df[var] for var in alpha_demographics)

    # 7. Final utility
    df["utility"] = (
        beta_0
        + U_demo
        + U_behavior
        + race_contrib
        + state_contrib
        - price * alpha_i
        + epsilon
    )

    # 8. Purchase decision
    df["purchase"] = (df["utility"] > 0).astype(int)

    return df

import numpy as np

def compute_individual_utility(hh, price,
                               beta_demographics, beta_behavior,
                               alpha_demographics,
                               race_effects=None, state_effects=None,
                               epsilon_std=1.0, random_state=None,
                               rng=None,
                               macro_state=1,
                               macro_utility_shift_bad=-0.10):
    """
    Compute utility and purchase decision for a single individual.

    Parameters
    ----------
    hh : pd.Series or dict
        Individual household record (one row from df_households).

    price : float
        Product price offered to the consumer.

    beta_demographics : dict
        Coefficients for demographic characteristics (e.g. income, age, family size).

    beta_behavior : dict
        Coefficients for behavioral variables (e.g. affinity, ad sensitivity).

    alpha_demographics : dict
        Coefficients governing how demographics interact with price sensitivity.

    race_effects : dict, optional
        Fixed effects by race (e.g. {'race_white': 0.2, 'race_black': -0.1})

    state_effects : dict, optional
        Fixed effects by state (e.g. {'state_CA': 0.3, 'state_TX': -0.2})

    epsilon_std : float, default=1.0
        Standard deviation of random noise in utility.

    random_state : int, optional
        Random seed for reproducibility.

    Returns
    -------
    dict
        {
            "utility": float,
            "purchase": int
        }
    """
    if random_state is not None:
            np.random.seed(random_state)
            
    U_demo = sum(beta_demographics[var] * hh[var] for var in beta_demographics)
    U_behavior = sum(beta_behavior[var] * hh[var] for var in beta_behavior)
    alpha_i = sum(alpha_demographics[var] * hh[var] for var in alpha_demographics)

    race_contrib = 0.0
    if race_effects:
        for col, eff in race_effects.items():
            if col in hh and hh[col] == 1:
                race_contrib += eff

    state_contrib = 0.0
    if state_effects:
        for col, eff in state_effects.items():
            if col in hh and hh[col] == 1:
                state_contrib += eff

    if rng is None:
        rng = np.random.default_rng(random_state)
    epsilon = rng.normal(0, epsilon_std)
    macro_shift = macro_utility_shift_bad if macro_state == 0 else 0.0

    utility = (
        U_demo
        + U_behavior
        + race_contrib
        + state_contrib
        - price * alpha_i
        + epsilon
        + macro_shift
    )

    return {"utility": float(utility), "purchase": int(utility > 0)}